package com.example.javatest;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends Activity {

    private ListView list;
    Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        list = findViewById(R.id.list_view);

        String[] data1 = new String[25];
        String[] data2 = new String[25];
        String[] data3 = new String[25];

        for (int i = 0; i < 25; i++) {
            int r1 = random.nextInt(101);
            int r2 = random.nextInt(100);
            data1[i] = "$" + r1 + "." + r2;
            data2[i] = "1/1/2024";
            data3[i] = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.";
        }

        CustomAdapter adapter = new CustomAdapter(this, data1, data2, data3);
        list.setAdapter(adapter);
    }

    private class CustomAdapter extends ArrayAdapter<String> {
        private final Activity context;
        private final String[] data1;
        private final String[] data2;
        private final String[] data3;

        public CustomAdapter(Activity context, String[] data1, String[] data2, String[] data3) {
            super(context, R.layout.list_item, data1);
            this.context = context;
            this.data1 = data1;
            this.data2 = data2;
            this.data3 = data3;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            LayoutInflater inflater = context.getLayoutInflater();
            View rowView = inflater.inflate(R.layout.list_item, null, true);

            TextView textView1 = rowView.findViewById(R.id.amount);
            TextView textView2 = rowView.findViewById(R.id.date);
            TextView textView3 = rowView.findViewById(R.id.description);

            textView1.setText(data1[position]);
            textView2.setText(data2[position]);
            textView3.setText(data3[position]);

            return rowView;
        }
    }
}
